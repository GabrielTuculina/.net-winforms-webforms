﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using FleetSupport.ApiExplorer.Others;
using FleetSupport.ApiExplorer.Entities;
using System.Reflection;
using FleetSupport.ApiExplorer.Entities.Inherited;

namespace FleetSupport.ApiExplorer
{
    public sealed partial class IndexForm : Form
    {
        private static readonly IndexForm instance = new IndexForm();
        private string className;
        private TextBox textBox;
        private readonly string URL = "http://localhost:50875/api/";

        /// Explicit static constructor to tell C# compiler
        /// not to mark type as beforefieldinit
        static IndexForm()
        {
        }

        private IndexForm()
        {
            InitializeComponent();
        }

        public static IndexForm Instance
        {
            get
            {
                return instance;
            }
        }

        private async void dataGridView1_CellContentClickAsync(object sender, DataGridViewCellEventArgs e)
        {
            // check if details cell or delete cell
            if(dataGridView1.CurrentCell.OwningColumn.HeaderText.Equals("Press for details"))
            {
                label1.Text = "pending from " + URL + className;
                await Task.Delay(5000);
                label1.Text = "";

                // get id
                int i, id;

                for (i = 0; i < dataGridView1.ColumnCount; ++i)
                    if (dataGridView1.Columns[i].HeaderText == "identifier")
                        break;

                id = (int)dataGridView1.CurrentRow.Cells[i].Value;

                // fetch data from server for id
                // transition to another form
                dataGridView1_DetailsClick(id);
            }

            if (dataGridView1.CurrentCell.OwningColumn.HeaderText.Equals("Delete if necessary"))
            {
                label1.Text = "updating to " + URL + className;
                await Task.Delay(5000);
                label1.Text = "";

                dataGridView1.Rows.RemoveAt(e.RowIndex);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // delete every entity besides the combobox and datagridview
            for (int i = this.Controls.Count - 1; i >= 0; --i)
                if (this.Controls[i] is Button || this.Controls[i] is TextBox)
                    this.Controls.Remove(this.Controls[i]);

            // parameters for location
            int x = 12;
            int y = 129;

            className = comboBox1.Text + "Properties";

            dynamic obj = createObjectFromName();

            // get http methods for the selected entity
            PropertyInfo pi = obj.GetType().GetProperty("ApiProperties");
            string[] properties = (string[])pi.GetValue(obj, null);

            // create buttons for some of the http methods
            if (properties.Contains("get_all"))
            {
                Button b1 = createButton("get_all", x, y);
                b1.Click += new System.EventHandler(this.button1_ClickAsync);

                y += 50;
            }

            if (properties.Contains("get_by_id"))
            {
                Button b2 = createButton("get_by_id", x, y);
                b2.Click += new System.EventHandler(this.button2_ClickAsync);

                y += 50;

                textBox = createTextBox(x, y);

                y += 50;
            }

            if (properties.Contains("post"))
            {
                Button b3 = createButton("post", x, y);
                b3.Click += new System.EventHandler(this.button3_Click);
            }

            // refresh the datagrid
            dataGridView1.Columns.Clear();
            dataGridView1.Refresh();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dynamic obj = createObjectFromName();

            helper_blankform(obj);
        }

        private async void button2_ClickAsync(object sender, EventArgs e)
        {
            if (textBox.Text != "")
            {
                label1.Text = "pending from " + URL + className;
                await Task.Delay(2000);
                label1.Text = "";

                dynamic obj = createObjectFromName();

                int id = int.Parse(textBox.Text);

                /// use a helper function to get that single instance off the database
                helper_datagridview(obj, id);
            }
        }

        private async void button1_ClickAsync(object sender, EventArgs e)
        {
            label1.Text = "pending from " + URL + className;
            await Task.Delay(2000);
            label1.Text = "";

            dynamic obj = createObjectFromName();

            this.datagridviewDisplayData(obj, className);
        }

        private void dataGridView1_DetailsClick(int id)
        {
            dynamic obj = createObjectFromName();

            helper_datagridview(obj, id);
        }




        /// internal usage
        private void datagridviewDisplayData(dynamic objectType, string entityName)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Columns.Clear();
            dataGridView1.Refresh();

            helper_button(objectType, dataGridView1);

            // delete inherited ApiEntityName
            dataGridView1.Columns.RemoveAt(dataGridView1.Columns.Count - 1);

            this.additionsDataGridView();
        }

        private object createObjectFromName()
        {
            string fullPath = "FleetSupport.ApiExplorer.Entities." + className;
            Type entityType = Type.GetType(fullPath);
            object obj = Activator.CreateInstance(entityType);

            return obj;
        }

        private void additionsDataGridView()
        {
            // delete button
            DataGridViewButtonColumn deleteButtonColumn = new DataGridViewButtonColumn();
            deleteButtonColumn.Name = "Delete if necessary";
            deleteButtonColumn.Text = "Delete";
            deleteButtonColumn.UseColumnTextForButtonValue = true;

            dataGridView1.Columns.Add(deleteButtonColumn);

            // details button
            DataGridViewButtonColumn detailsButtonColumn = new DataGridViewButtonColumn();
            detailsButtonColumn.Name = "Press for details";
            detailsButtonColumn.Text = "Details";
            detailsButtonColumn.UseColumnTextForButtonValue = true;

            dataGridView1.Columns.Add(detailsButtonColumn);
        }





        /// methods that help transforming the class name in class type for further usage
        private void helper_button<T>(T ignored, DataGridView d) where T : BaseModel, new()
        {
            d.DataSource = WebDataFetch<T>.GetItems();
        }

        private void helper_datagridview<T>(T ignored, int id) where T : BaseModel, new()
        {
            TransferSelectedProperties<T>.entity = WebDataFetch<T>.GetItem(id);
            EntityDetailsForm<T> form = new EntityDetailsForm<T>();
            this.Hide();
            form.ShowDialog();
        }

        private void helper_blankform<T>(T ignored) where T : BaseModel, new()
        {
            TransferSelectedProperties<T>.entity = null;
            EntityDetailsForm<T> form = new EntityDetailsForm<T>();
            this.Hide();
            form.ShowDialog();
        }





        /// creating entities
        private Button createButton(string name, int x, int y)
        {
            Button button = new Button();
            button.Size = new System.Drawing.Size(126, 36);
            button.Location = new System.Drawing.Point(x, y);
            button.TabIndex = 0;
            button.Text = name.ToUpper();
            button.UseVisualStyleBackColor = true;
            this.Controls.Add(button);

            return button;
        }

        private TextBox createTextBox(int x, int y)
        {
            TextBox textBox = new TextBox();
            textBox.Size = new System.Drawing.Size(126, 36);
            textBox.Location = new System.Drawing.Point(x, y);
            textBox.TabIndex = 0;
            this.Controls.Add(textBox);

            return textBox;
        }
    }
}
