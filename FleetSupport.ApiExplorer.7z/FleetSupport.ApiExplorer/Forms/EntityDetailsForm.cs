﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net;
using System.IO;

namespace FleetSupport.ApiExplorer
{
    public partial class EntityDetailsForm<T> : Form where T : new()
    {
        private string className;
        private readonly string URL = "http://localhost:50875/api/";

        public EntityDetailsForm()
        {
            InitializeComponent();
            this.Controls.Add(panel1);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1_Paint_1(sender, null);
        }

        private void carPictureBox_Click(object sender, EventArgs e)
        {
            DialogResult dr = openFileDialog.ShowDialog();
            if (dr == System.Windows.Forms.DialogResult.OK)
            {
                string file = openFileDialog.FileName;
                carPictureBox.Image = Image.FromFile(file);
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Dispose(true);
            this.Hide();
            IndexForm form = IndexForm.Instance;
            form.Show();
        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {
            /* X0 = 332,  Y0 = 90  <-> coordonate initiale
             * Xl = 125,  Yl = 21  <-> dimensiunea unei forme
             *            Yi = 6   <-> distanta dintre perechile de forme
             * Xn = +155, Yn = 0   <-> coordonate noi la trecerea pe alta coloana
             * Xs = 6              <-> distanta intre label si textbox
             */

            int x0 = 10;
            int y0 = 10;

            int yi = 6;

            int xl = 125;
            int yl = 21;

            int xn = 280;

            int xs = 6;

            int x = x0;
            int y = y0;
            
            List<string> propertyList = new List<string>();
            foreach (var prop in (new T()).GetType().GetProperties())
            {
                if (prop.Name != "ApiEntityName" && prop.Name != "ApiProperties")
                    propertyList.Add(prop.Name);
            }

            // initialize locals
            string[] stringList = (new T()).GetType().ToString().Split(' ');
            className = stringList[stringList.Length - 1];

            var bindingFlags = BindingFlags.Instance |
                      BindingFlags.NonPublic |
                      BindingFlags.Public;
            List<object> fieldValues = new List<object>();

            if (TransferSelectedProperties<T>.entity != null)
            {
                fieldValues = TransferSelectedProperties<T>.entity.GetType()
                     .GetFields(bindingFlags)
                     .Select(field => field.GetValue(TransferSelectedProperties<T>.entity))
                     .ToList();
            }

            for (int i = 0; i < propertyList.Count; ++i)
            {
                Label label = new Label();
                label.Location = new Point(x, y);
                label.Size = new Size(xl, yl);
                label.Text = propertyList[i];
                panel1.Controls.Add(label);

                if (TransferSelectedProperties<T>.entity != null)
                {
                    if (fieldValues[i].ToString().Length <= 20)
                    {
                        TextBox textBox = new TextBox();
                        textBox.Location = new Point(x + xl + xs, y);
                        textBox.Size = new Size(xl, yl);
                        textBox.Text = fieldValues[i].ToString();
                        panel1.Controls.Add(textBox);

                        // new entry
                        y += yl + yi;
                    }
                    else
                    {
                        RichTextBox textBox = new RichTextBox();
                        textBox.Location = new Point(x + xl + x, y);
                        textBox.Size = new Size(xl, 3 * yl);
                        textBox.Text = fieldValues[i].ToString();
                        panel1.Controls.Add(textBox);

                        // new entry
                        y += yl * 3 + yi;
                    }
                }
                else
                {
                    TextBox textBox = new TextBox();
                    textBox.Location = new Point(x + xl + xs, y);
                    textBox.Size = new Size(xl, yl);
                    textBox.Text = "";
                    panel1.Controls.Add(textBox);

                    // new entry
                    y += yl + yi;
                }


                // new column
                if ((i + 1) % 15 == 0)
                {
                    x = x0 + xn + xs;
                    x0 = x;
                    y = y0;
                }
            }
            TransferSelectedProperties<T>.entity = default(T);
        }

        private async void button1_ClickAsync(object sender, EventArgs e)
        {
            label1.Text = "updating to " + URL + className;
            await Task.Delay(5000);
            label1.Text = "";

            T entity = new T();
            PropertyInfo propertyInfo;
            
            for (int i = 0; i < panel1.Controls.Count; i += 2)
            {
                propertyInfo = entity.GetType().GetProperty(panel1.Controls[i].Text);
                propertyInfo.SetValue(entity, Convert.ChangeType(panel1.Controls[i + 1].Text, propertyInfo.PropertyType), null);
            }

            var json = JsonConvert.SerializeObject(entity);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL + className);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            var array = Encoding.ASCII.GetBytes(json);
            request.ContentLength = array.Length;

            using (Stream postdata = request.GetRequestStream())
            {
                postdata.Write(array, 0, array.Length);
            }
        }
    }
}
