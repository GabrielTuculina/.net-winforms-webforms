﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FleetSupport.ApiExplorer
{
    public class CarCollection
    {
        private List<Car> carCollection;

        public List<Car> CarCollection { get => carCollection; set => carCollection = value; }
    }
}
