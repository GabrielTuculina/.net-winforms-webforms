﻿using FleetSupport.ApiExplorer.Entities.Inherited;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace FleetSupport.ApiExplorer.Others
{
    static class WebDataFetch<T> where T : BaseModel, new()
    {
        private static string FetchData(string link)
        {
            WebClient wc = new WebClient();
            var json = wc.DownloadString(link);
            json = json.TrimStart('\"');
            json = json.TrimEnd('\"');
            json = json.Replace("\\", "");

            return json;
        }

        public static BindingList<T> GetItems()
        {
            string link = "http://localhost:50875/api/";
            T newT = new T();
            link += newT.ApiEntityName;

            var json = FetchData(link);

            BindingList<T> className = JToken.Parse(json).ToObject<BindingList<T>>();

            return className;
        }

        public static T GetItem(int id)
        {
            string link = "http://localhost:50875/api/";
            T newT = new T();
            link += newT.ApiEntityName + "/" + id;

            var json = FetchData(link);

            T className = JToken.Parse(json).ToObject<T>();

            return className;
        }

        
    }
}
