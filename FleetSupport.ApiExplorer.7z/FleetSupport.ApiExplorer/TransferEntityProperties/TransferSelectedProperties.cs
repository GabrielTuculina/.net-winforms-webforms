﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FleetSupport.ApiExplorer
{
    static class TransferSelectedProperties<T>
    {
        public static T entity { get; set; }
    }
}
