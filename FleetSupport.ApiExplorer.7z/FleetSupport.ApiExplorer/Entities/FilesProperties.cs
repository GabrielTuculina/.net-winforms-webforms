﻿using FleetSupport.ApiExplorer.Entities.Inherited;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetSupport.ApiExplorer.Entities
{
    class FilesProperties : BaseModel
    {
        public FilesProperties()
        {
            ApiEntityName = "files";
            ApiProperties = new string[] { "get_by_id", "post", "patch" };
        }

        public string name { get; set; }
        public string original_name { get; set; }
        public string description { get; set; }
        public string mime_type { get; set; }
        public int identifier { get; set; }
    }
}
