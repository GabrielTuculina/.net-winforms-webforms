﻿using FleetSupport.ApiExplorer.Entities.Inherited;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetSupport.ApiExplorer.Entities
{
    class ContractsProperties : BaseModel
    {
        public ContractsProperties()
        {
            ApiEntityName = "contracts";
            ApiProperties = new string[] { "get_all", "get_by_id" };
        }
      

        public int supplier_code { get; set; }
        public int number { get; set; }
        public int entry { get; set; }
        public int relation_code { get; set; }
        public string contract_type_name { get; set; }
        public string contract_state_name { get; set; }
        public DateTime start_date { get; set; }
        public DateTime end_date { get; set; }
        public DateTime expected_contract_end_date { get; set; }
        public int duration { get; set; }
        public int max_approved_duration { get; set; }
        public int identifier { get; set; }
    }
}
