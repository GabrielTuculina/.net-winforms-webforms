﻿using FleetSupport.ApiExplorer.Entities.Inherited;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetSupport.ApiExplorer.Entities
{
    class DossiersProperties : BaseModel
    {
        public DossiersProperties()
        {
            ApiEntityName = "dossiers";
            ApiProperties = new string[] { "get_all", "get_by_id", "post", "patch" };
        }

        public string name { get; set; }
        public int person_id { get; set; }
        public int relation_code { get; set; }
        public int identifier { get; set; }
    }
}
