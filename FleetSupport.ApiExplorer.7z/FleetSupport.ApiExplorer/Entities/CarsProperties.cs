﻿using FleetSupport.ApiExplorer.Entities.Inherited;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetSupport.ApiExplorer.Entities
{
    class CarsProperties : BaseModel
    {
        public CarsProperties()
        {
            ApiEntityName = "cars";
            ApiProperties = new string[] { "get_all", "get_by_id" };
        }
        
        public string license { get; set; }
        public string chassis_number { get; set; }
        public string car_brand_type_id { get; set; }
        public string implementation { get; set; }
        public string car_color_name { get; set; }
        public string fuel { get; set; }
        public string tax { get; set; }
        public string catalog_value { get; set; }
        public string date_part_1 { get; set; }
        public string date_part_2 { get; set; }
        public string start_date { get; set; }
        public string norm_lease { get; set; }
        public string car_type { get; set; }
        public int build_year { get; set; }
        public int model_year { get; set; }
        public string default_preferences { get; set; }
        public double cylinder_capacity_ccm { get; set; }
        public double weight { get; set; }
        public double weight_fully { get; set; }
        public double weight_empty { get; set; }
        public int number_of_cylinders { get; set; }
        public double performance_kw { get; set; }
        public double loading_capacity { get; set; }
        public string transmission { get; set; }
        public int doors_total { get; set; }
        public bool wheels_driven { get; set; }
        public string body_style { get; set; }
        public string co2 { get; set; }
        public string co2_label { get; set; }
        public double fiscal_addition_new_rate { get; set; }
        public string registration_country { get; set; }
        public double fuel_tank_volume { get; set; }
        public double net_catalog_price { get; set; }
        public double bpm_catalog_price { get; set; }
        public double fuel_consumption_l_100_km { get; set; }
        public double factory_fuel_consumption_l_100_km { get; set; }
        public string contract_type { get; set; }
        public double year_kilometrage_real { get; set; }
        public int identifier { get; set; }
    }
}
