﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetSupport.ApiExplorer.Entities.Inherited
{
    public class BaseModel
    {
        public string ApiEntityName { get; set; }
        public string[] ApiProperties { get; set; }
    }
}
