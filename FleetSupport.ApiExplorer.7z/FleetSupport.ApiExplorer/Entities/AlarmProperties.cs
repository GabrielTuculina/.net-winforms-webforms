﻿using FleetSupport.ApiExplorer.Entities.Inherited;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetSupport.ApiExplorer.Entities
{
    class AlarmProperties : BaseModel
    {
        public AlarmProperties()
        {
            ApiEntityName = "alarm";
            ApiProperties = new string[] { "post" };
        }

        public int seconds { get; set; }
        public int identifier { get; set; }
    }
}
