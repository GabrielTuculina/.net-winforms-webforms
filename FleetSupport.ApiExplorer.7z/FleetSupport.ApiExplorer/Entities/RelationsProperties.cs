﻿using FleetSupport.ApiExplorer.Entities.Inherited;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetSupport.ApiExplorer.Entities
{
    class RelationsProperties : BaseModel
    {
        public RelationsProperties()
        {
            ApiEntityName = "relations";
            ApiProperties = new string[] { "get_all", "get_by_id", "post", "patch" };
        }

        public string code { get; set; }
        public string name { get; set; }
        public DateTime start_date { get; set; }
        public DateTime end_date { get; set; }
        public string benchmark_reference { get; set; }
        public int identifier { get; set; }
    }
}
