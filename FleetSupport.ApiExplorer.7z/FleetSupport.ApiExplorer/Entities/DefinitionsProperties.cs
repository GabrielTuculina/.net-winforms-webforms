﻿using FleetSupport.ApiExplorer.Entities.Inherited;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetSupport.ApiExplorer.Entities
{
    class DefinitionsProperties : BaseModel
    {
        public DefinitionsProperties()
        {
            ApiEntityName = "definitions";
            ApiProperties = new string[] { "get_all" };
        }

        public string name { get; set; }
        public string type { get; set; }
        public int relation_code { get; set; }
        public int dossier_phase_step_id { get; set; }
        public DateTime start_date { get; set; }
        public DateTime end_date { get; set; }
        public int identifier { get; set; }
    }
}
