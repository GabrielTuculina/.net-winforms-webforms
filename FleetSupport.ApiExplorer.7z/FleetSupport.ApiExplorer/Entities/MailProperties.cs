﻿using FleetSupport.ApiExplorer.Entities.Inherited;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetSupport.ApiExplorer.Entities
{
    class MailProperties : BaseModel
    {
        public MailProperties()
        {
            ApiEntityName = "mai";
            ApiProperties = new string[] { "post" };
        }

        public string subject { get; set; }
        public string from_display { get; set; }
        public string from_address { get; set; }
        public string to_display { get; set; }
        public string to_address { get; set; }
        public string html { get; set; }
        public string text { get; set; }
        public string type { get; set; }
        public string attachments { get; set; }
        public string sent_at { get; set; }
        public int identifier { get; set; }
    }
}
