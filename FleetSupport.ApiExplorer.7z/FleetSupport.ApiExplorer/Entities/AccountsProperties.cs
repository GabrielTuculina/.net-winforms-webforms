﻿using FleetSupport.ApiExplorer.Entities.Inherited;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FleetSupport.ApiExplorer.Entities
{
    class AccountsProperties : BaseModel
    {
        public AccountsProperties()
        {
            ApiEntityName = "accounts";
            ApiProperties = new string[] { "get_all", "get_by_id", "post", "patch" };
        }

        public DateTime start_timestamp { get; set; }
        public string role_name { get; set; }
        public DateTime end_timestamp { get; set; }
        public string password { get; set; }
        public string agreed_conditions { get; set; }
        public int identifier { get; set; }
    }
}
